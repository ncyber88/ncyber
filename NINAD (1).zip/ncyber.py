
# ncyber.py - Project Entry Point for NCyber Toolkit
import os
import click

@click.group()
def cli():
    """NCyber: Modular Cybersecurity Toolkit Launcher"""
    pass

@cli.command()
def cli_mode():
    os.system("python3 cli.py")

@cli.command()
def gui_mode():
    os.system("python3 gui/app.py")

@cli.command()
def info():
    print("""
NCYBER - Modular Cybersecurity Toolkit
--------------------------------------
Modules: Recon, Exploit, RAT, Web, WiFi, OSINT, Forensics, AD Enum, Cloud, Container
Interface: CLI & Web Dashboard
Data Storage: SQLite (logs/ncyber.db)

Usage:
  python3 ncyber.py cli-mode       # Launch CLI interface
  python3 ncyber.py gui-mode       # Launch Web GUI
  python3 ncyber.py info           # Show info

Github: https://github.com/yourusername/ncyber
    """)

if __name__ == '__main__':
    cli()
