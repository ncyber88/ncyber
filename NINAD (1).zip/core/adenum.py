# AD enumeration module
