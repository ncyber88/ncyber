# Container inspection module
