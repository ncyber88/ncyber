# SQLite log handler
